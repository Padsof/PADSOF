package gui.mainform;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SpringLayout;

public class FormPanelRegistro extends JPanel {

	public FormPanelRegistro(RegistroFrame registroFrame) {
		
		SpringLayout layout = new SpringLayout(); // Layout basado en restricciones...     
		this.setLayout(layout); 
		
		JLabel etiqueta = new JLabel("Usuario");
		JTextField campo = new JTextField(10);
		JLabel etiqueta2 = new JLabel("DNI");
		JTextField campo2 = new JTextField(9);
		JLabel etiqueta3 = new JLabel("Contrase�a");
		JPasswordField campo3 = new JPasswordField(10); 
		JPanel ejemploPasswordField = new JPanel(new GridLayout(2,1,2,2)); 
		ejemploPasswordField.add(campo3); 				
		JButton boton = new JButton("Registrarse");
		
		layout.putConstraint(SpringLayout.WEST, etiqueta, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, etiqueta, 10, SpringLayout.NORTH, this); 
		 
		layout.putConstraint(SpringLayout.WEST, campo, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, campo, 20, SpringLayout.NORTH, etiqueta); 
		
		layout.putConstraint(SpringLayout.WEST, etiqueta2, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, etiqueta2, 20, SpringLayout.NORTH, campo); 
		
		layout.putConstraint(SpringLayout.WEST, campo2, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, campo2, 20, SpringLayout.NORTH, etiqueta2); 
		
		layout.putConstraint(SpringLayout.WEST, etiqueta3, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, etiqueta3, 20, SpringLayout.NORTH, campo2); 
		
		layout.putConstraint(SpringLayout.WEST, campo3, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, campo3, 20, SpringLayout.NORTH, etiqueta3); 
		
		layout.putConstraint(SpringLayout.WEST, boton, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, boton, 40, SpringLayout.NORTH, campo3); 
		
	

		this.add(etiqueta);
		this.add(campo);
		this.add(etiqueta2);
		this.add(campo2);
		this.add(etiqueta3);
		this.add(campo3);
		this.add(boton);
		
		this.setPreferredSize(new Dimension(250,250)); 

		
	}

}