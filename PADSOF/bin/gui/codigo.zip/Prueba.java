package gui;

import gui.control.*;
import gui.mainform.*;
public class Prueba {

public static void main(String[] args) {
		
		FormPanelInicio inicio = new FormPanelInicio(new InicioFrame());
		
		FormPanelRegistro registro = new FormPanelRegistro(new RegistroFrame());
		
		Registrate registrate = new Registrate (inicio, registro);
		
		inicio.setControlador(registrate);
			
	}
}
