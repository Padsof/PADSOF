package gui;

import gui.mainform.*;

public class Registro {

	public static void main(String[] args) {
		
		new RegistroFrame();
		
		}
	
}
