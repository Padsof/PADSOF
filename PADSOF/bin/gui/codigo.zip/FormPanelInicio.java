package gui.mainform;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class FormPanelInicio extends JPanel {
	
	 private JButton botonRegistrar;

	public FormPanelInicio(InicioFrame inicioFrame) {
		
		SpringLayout layout = new SpringLayout(); // Layout basado en restricciones...     
		this.setLayout(layout); 
				
		JLabel etiqueta = new JLabel("Usuario o DNI");
		JTextField campo = new JTextField(10);
		JLabel etiqueta2 = new JLabel("Contrase�a");
		JPasswordField campo2 = new JPasswordField(10); 
		JPanel ejemploPasswordField = new JPanel(new GridLayout(2,1,2,2)); 
		ejemploPasswordField.add(campo2); 
		JButton boton = new JButton("Iniciar Sesion");
		JLabel etiqueta3 = new JLabel("�Usuario nuevo?");
		botonRegistrar = new JButton("Registrate");
		
		layout.putConstraint(SpringLayout.WEST, etiqueta, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, etiqueta, 10, SpringLayout.NORTH, this); 
		 
		layout.putConstraint(SpringLayout.WEST, campo, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, campo, 20, SpringLayout.NORTH, etiqueta); 
		
		layout.putConstraint(SpringLayout.WEST, etiqueta2, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, etiqueta2, 20, SpringLayout.NORTH, campo); 
		
		layout.putConstraint(SpringLayout.WEST, campo2, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, campo2, 20, SpringLayout.NORTH, etiqueta2); 
		
		layout.putConstraint(SpringLayout.WEST, boton, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, boton, 40, SpringLayout.NORTH, campo2); 
		
		layout.putConstraint(SpringLayout.WEST, etiqueta3, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, etiqueta3, 40, SpringLayout.NORTH, boton); 
		
		layout.putConstraint(SpringLayout.WEST, botonRegistrar, 40, SpringLayout.WEST, this);         
		layout.putConstraint(SpringLayout.NORTH, botonRegistrar, 40, SpringLayout.NORTH, etiqueta3); 
		

		this.add(etiqueta);
		this.add(campo);
		this.add(etiqueta2);
		this.add(campo2);
		this.add(boton);
		this.add(etiqueta3);
		this.add(botonRegistrar);	
		
		this.setPreferredSize(new Dimension(250,250)); 
		
	}
	
	// m�todo para asignar un controlador al bot�n    
	
	public void setControlador(ActionListener c) {  
		//System.out.println("hola");
		botonRegistrar.addActionListener(c);   
	} 

}
