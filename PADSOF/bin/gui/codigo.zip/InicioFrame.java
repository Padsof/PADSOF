package gui.mainform;

import java.awt.*;

import javax.swing.*;

public class InicioFrame extends JFrame{
	
	private FormPanelInicio fp = new FormPanelInicio(this);

	public InicioFrame() {
		
		super("Iniciar Sesion");
		Container cp = this.getContentPane();
		cp.setLayout(new BorderLayout()); 
		cp.add(fp, BorderLayout.CENTER); 
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
		
	}



}
