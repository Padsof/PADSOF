package gui.mainform;

import java.awt.*;

import javax.swing.*;

public class RegistroFrame extends JFrame{
	
	private JPanel botonera = new JPanel();
	private FormPanelRegistro fp = new FormPanelRegistro(this);
	private JButton boton = new JButton("Volver");
	
	public RegistroFrame() {
		
		super("Registrarse");
		Container cp = this.getContentPane();
		cp.setLayout(new BorderLayout()); 
		
		botonera.add(boton); 
		cp.add(botonera, BorderLayout.SOUTH); 
		cp.add(fp, BorderLayout.CENTER); 
		this.pack();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(false);
		
		
	}
}
