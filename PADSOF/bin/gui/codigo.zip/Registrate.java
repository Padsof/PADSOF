package gui.control;

import java.awt.event.*;
import ads.PADSOF.*;
import gui.mainform.*;

public class Registrate  implements ActionListener {
	private FormPanelInicio inicio;
	private FormPanelRegistro registro;
	
	 public Registrate(FormPanelInicio vista, FormPanelRegistro vista2) { 

		 this.inicio  = vista;  
		 this.registro = vista2;
	 }
	 
	 public void actionPerformed(ActionEvent e) { 
		 		 
		 //System.out.println("hola");
		 inicio.setVisible(false);
		 registro.setVisible(true);
		 
		 
	 }
}
